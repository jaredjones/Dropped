<?php
echo "<head><title>Welcome to HipHop</title></head>";
echo "<h2>";
echo phpinfo();
echo "</h2><hr>";
echo "<iframe src=\"http://www.youtube.com/embed/Q0IGepU7ICc?loop=1&playlist=Q0IGepU7ICc&autoplay=1\" width=\"480\" height=\"360\" frameborder=\"0\" allowfullscreen></iframe>";

	echo "<p>I said a hip, hop, the hippie - the hippie
To the hip hip-hop, and you don't stop
The rock it to the bang-bang, boogie say \"up jump\"
The boogie to the rhythm of the boogie: the beat"
?>
