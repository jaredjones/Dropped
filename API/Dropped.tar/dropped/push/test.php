<?php

// My device token here (without spaces):
$deviceToken = '4a210a33af9d7a813b7806312fd4760ac4ccb59323753273065744da3e063c65';
//$deviceToken = 'f2b8c9fc5a92b2a24418f1f9c24ebbfb4f8cb373bd0502ea796f55821da9e0a0';
//$deviceToken = '5af0ebcebb86bbcc265d654578006e54b7d3185b83d88ad90e0afb4447550a19';

// My private key's passphrase here:
$passphrase = '';

// My alert message here:
$message = 'Say Goodbye to the Notification!';

//badge
$badge = 0;

$ctx = stream_context_create();
stream_context_set_option($ctx, 'ssl', 'local_cert', 'DRPPubPrivCert.pem');
stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

// Open a connection to the APNS server
$fp = stream_socket_client(
    'ssl://gateway.sandbox.push.apple.com:2195', $err,
    $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

if (!$fp)
exit("Failed to connect: $err $errstr" . PHP_EOL);

echo 'Connected to APNS' . PHP_EOL;

// Create the payload body
$body['aps'] = array(
    'alert' => $message,
    'badge' => $badge,
    'sound' => 'newMessage.wav'
);

// Encode the payload as JSON
$payload = json_encode($body);

// Build the binary notification
$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
$result = fwrite($fp, $msg, strlen($msg));

if (!$result)
    echo 'Error, notification not sent' . PHP_EOL;
else
    echo 'notification sent!' . PHP_EOL;

// Close the connection to the server
fclose($fp);
?>
