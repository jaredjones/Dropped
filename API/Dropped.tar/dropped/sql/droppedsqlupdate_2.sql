INSERT OR IGNORE INTO words(word) values('zeis');
INSERT OR IGNORE INTO words(word) values('novak');

