INSERT OR IGNORE INTO words(word) values('twat');
