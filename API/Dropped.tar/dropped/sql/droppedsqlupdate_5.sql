INSERT OR IGNORE INTO words(word) values('milkshake');
INSERT OR IGNORE INTO words(word) values('ragdoll');
INSERT OR IGNORE INTO words(word) values('milkshakes');
INSERT OR IGNORE INTO words(word) values('diaspora');
INSERT OR IGNORE INTO words(word) values('systematists');
INSERT OR IGNORE INTO words(word) values('systematist');
INSERT OR IGNORE INTO words(word) values('instantiator');
INSERT OR IGNORE INTO words(word) values('instantiators');

