INSERT OR IGNORE INTO words(word) values('milkshakes');
INSERT OR IGNORE INTO words(word) values('instantiator');
INSERT OR IGNORE INTO words(word) values('instantiators');

